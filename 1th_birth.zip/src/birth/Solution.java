package birth;

public class Solution {
	/*public int solution(int n) {
		int answer = 0;
        int nLen = 0;
        
        String param = String.valueOf(n);
        nLen = param.length();
        
        for( int i = 0; i < nLen; i++ ){
        	String temp = String.valueOf(param.charAt(i));
        	answer += Integer.parseInt(temp);
        }
        
		return answer;
	}*/
	public int solution(int sticker[]) {
		int answer = 36;
		return answer;
	}
	public static void main ( String[] args ){
		Solution st = new Solution();
		//System.out.println(st.solution());
	}
}
